import React, { useState, useEffect } from "react";
// import Footer from "../footer/Footer";
// import Header from "../header/Header";
import { Outlet } from "react-router-dom";

function Wrapper() {
  const [isFixed, setIsFixed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 350) {
        // Adjust the scroll position as needed
        setIsFixed(true);
      } else {
        setIsFixed(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
      {/* <Header /> */}
      <main className="min-h-[calc(100vh-138px)] bg-white mt-[92px]">
        <Outlet />
      </main>
      {/* <Footer /> */}
    </>
  );
}

export default Wrapper;
