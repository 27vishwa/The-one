import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { Employee } from "../../types/Employee";

export interface IUserInitialRedux {
  employee: Employee[];
}

const initialState = {
  employee: [],
};

export const employeeSlice = createSlice({
  name: "employee",
  initialState,
  reducers: {
    setEmployee: (
      state: IUserInitialRedux,
      action: PayloadAction<Employee[]>
    ) => {
      state.employee = action.payload;
    },
  },
});

export const employeeSelector = (state: { employee: IUserInitialRedux }) =>
  state.employee.employee;

const { actions, reducer } = employeeSlice;

export const { setEmployee } = actions;

export const setemployee = (data: Employee[]) => {
  setEmployee(data);
};

export default reducer;
