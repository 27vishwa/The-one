import { combineReducers } from "redux";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import employeeReducer from "./slices/employeeSlice";

const persistConfig = {
  key: "the_one_tech",
  storage,
  whitelist: ["employee"],
};

const rootReducer = combineReducers({
  employee: employeeReducer,
});

export default persistReducer(persistConfig, rootReducer);
