import { ReactNode } from "react";

export interface ModalProps {
  open: boolean;
  onClose?: () => void;
  header?: boolean;
  children: ReactNode;
  width?: string;
  headingText?: string;
}
