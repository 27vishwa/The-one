import React, { lazy } from "react";
import { paths } from "./path";
const EmployeeList = lazy(() => import("../pages/EmployeeList"));

export const OtherRoutes = [
  {
    id: 1,
    path: paths.web.dashboard,
    name: "Dashboard",
    element: EmployeeList,
  },
];
