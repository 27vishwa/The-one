export const paths = {
  web: {
    dashboard: "/",
  },
};
