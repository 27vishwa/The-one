import React, { lazy } from "react";
import { Route, Routes } from "react-router-dom";
import { OtherRoutes } from "./routes";
import NotFound from "../pages/notfound/NotFound";

const Wrapper = lazy(() => import("../components/themeComponents/Wrapper"));

const AppRoutes = () => {
  return (
    <Routes>
      <Route element={<Wrapper />}>
        {(OtherRoutes || [])?.map((route, id) => (
          <Route key={id} path={route.path} element={<route.element />} />
        ))}
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;
