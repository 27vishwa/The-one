import React from "react";

function NotFound() {
  return (
    <div className="h-screen flex items-center justify-center bg-[#F6F8FA]">
      <div className="container mx-auto ">
        <div className="grid grid-cols-12">
          <div className="card p-6 text-center lg:col-span-6 lg:col-start-4 md:col-span-8 md:col-start-3 col-span-12">
            <h1 className="font-bold mb-4 text-4xl sm:text-5xl">
              Page Not Found
            </h1>
            <p className="mb-8">
              Seems like nothing was found at this location. Try something else
              or you can go back to the homepage following the button below!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NotFound;
