import React, { useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import { Employee } from "../types/Employee";
import { useDispatch, useSelector } from "react-redux";
import { employeeSelector, setEmployee } from "../redux/slices/employeeSlice";
import AddEmployee from "./AddEmployee";

const EmployeeList: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const [itemsPerPage] = useState(5);
  const [loading, setLoading] = useState<boolean>(true);
  const [isModalOpen, setModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState<boolean>(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<number | null>(null);
  const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);
  const dispatch = useDispatch();
  const employee = useSelector(employeeSelector) || [];

  // Fetch employees from API
  const fetchEmployees = async () => {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/users"
      );
      if (!response.ok) {
        throw new Error("Failed to fetch employees");
      }
      const data: Employee[] = await response.json();
      const filteredData = data?.map(({ name, username, email, id }) => ({
        id,
        name,
        username,
        email,
      }));
      dispatch(setEmployee(filteredData || []));
    } catch (error) {
      console.error("Error fetching employees:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch employees on component mount
  useEffect(() => {
    fetchEmployees();
  }, []);

  // Handle delete action
  const handleDelete = async (id: number) => {
    try {
      const response = await fetch(
        `https://jsonplaceholder.typicode.com/users/${id}`,
        { method: "DELETE" }
      );
      if (!response.ok) {
        throw new Error("Failed to delete employee");
      }
      const updatedEmployees = employee?.filter((emp) => emp.id !== id);
      dispatch(setEmployee(updatedEmployees));
      console.log(`Employee with id ${id} deleted successfully.`);
    } catch (error) {
      console.error("Error deleting employee:", error);
    } finally {
      setDeleteModalOpen(false); // Close modal after deletion or error
    }
  };

  // Handle page change
  const handlePageClick = (event: { selected: number }) => {
    setCurrentPage(event.selected);
  };

  // Get current page's employees
  const pageStart = currentPage * itemsPerPage;
  const currentEmployees = employee?.slice(pageStart, pageStart + itemsPerPage);

  if (loading) {
    return (
      <p className="text-center text-gray-600 mt-10">Loading employees...</p>
    );
  }

  // Close delete confirmation modal
  const handleCloseDeleteModal = () => {
    setDeleteModalOpen(false);
    setEmployeeToDelete(null);
  };

  // Open edit modal
  const handleEditClick = (employee: Employee) => {
    setEmployeeToEdit(employee);
    setModalOpen(true);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">Employee List</h1>
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded mb-4 hover:bg-blue-600"
        onClick={() => setModalOpen(true)}
      >
        Add Employee
      </button>

      {/* Employee List */}
      <ul className="bg-white shadow-md rounded-md divide-y divide-gray-200">
        {currentEmployees?.map((employee) => (
          <li
            key={employee.id}
            className="p-4 flex justify-between items-center"
          >
            <div>
              <p className="font-semibold">{employee.name}</p>
              <p className="text-sm text-gray-500">{employee.email}</p>
              <p className="text-sm text-gray-500">{employee.username}</p>
            </div>
            <div className="flex space-x-3">
              <button
                className="text-blue-500 hover:text-blue-700"
                title="Edit Employee"
                onClick={() => handleEditClick(employee)}
              >
                ✎
              </button>
              <button
                className="text-red-500 hover:text-red-700"
                title="Delete Employee"
                onClick={() => {
                  setEmployeeToDelete(employee.id || 0);
                  setDeleteModalOpen(true);
                }}
              >
                🗑
              </button>
            </div>
          </li>
        ))}
      </ul>

      {/* Pagination */}
      <ReactPaginate
        previousLabel={"← Previous"}
        nextLabel={"Next →"}
        breakLabel={"..."}
        pageCount={Math.ceil(employee?.length / itemsPerPage)}
        marginPagesDisplayed={2}
        pageRangeDisplayed={3}
        onPageChange={handlePageClick}
        containerClassName={"flex justify-center mt-6"}
        pageClassName={"px-3 py-1 border rounded hover:bg-gray-200 mx-1"}
        activeClassName={"bg-blue-500 text-white"}
        previousClassName={"px-3 py-1 border rounded hover:bg-gray-200 mx-1"}
        nextClassName={"px-3 py-1 border rounded hover:bg-gray-200 mx-1"}
        breakClassName={"px-3 py-1 border rounded hover:bg-gray-200 mx-1"}
      />

      {/* Add or Edit Employee Modal */}
      {isModalOpen && (
        <AddEmployee
          onClose={() => setModalOpen(false)}
          fetchEmployees={fetchEmployees}
          employeeToEdit={employeeToEdit}
        />
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && employeeToDelete !== null && (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 className="text-xl font-semibold mb-4">Are you sure?</h3>
            <p className="mb-4">
              Are you sure you want to delete this employee?
            </p>
            <div className="flex justify-between">
              <button
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                onClick={() => handleDelete(employeeToDelete)}
              >
                Yes, Delete
              </button>
              <button
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                onClick={handleCloseDeleteModal}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeList;
