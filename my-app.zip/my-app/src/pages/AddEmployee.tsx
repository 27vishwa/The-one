import React, { useEffect } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { employeeSelector, setEmployee } from "../redux/slices/employeeSlice";
import { Employee } from "../types/Employee";

interface EmployeeInterface {
  onClose: () => void;
  fetchEmployees: () => void; // Callback to refresh employee list after adding or editing
  employeeToEdit?: Employee | null; // Optional prop for editing an employee
}

const AddEmployee = ({
  onClose,
  fetchEmployees,
  employeeToEdit,
}: EmployeeInterface) => {
  const dispatch = useDispatch();
  const existingEmployees = useSelector(employeeSelector) || [];

  // Set initial values for the form if editing
  const initialValues = {
    name: employeeToEdit?.name || "",
    username: employeeToEdit?.username || "",
    email: employeeToEdit?.email || "",
  };

  const onSubmit = async (values: {
    name: string;
    username: string;
    email: string;
  }) => {
    try {
      let response;
      let updatedEmployees = [...existingEmployees]; // Make a copy of the existing employees

      if (employeeToEdit) {
        // If editing, make PUT request to update
        response = await fetch(
          `https://jsonplaceholder.typicode.com/users/${employeeToEdit.id}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(values),
          }
        );
        if (!response.ok) throw new Error("Failed to update employee");
        updatedEmployees = updatedEmployees.map((emp) =>
          emp.id === employeeToEdit.id ? { ...emp, ...values } : emp
        );
        dispatch(setEmployee([...updatedEmployees])); // Update the store
      } else {
        // If adding new employee, make POST request to add
        response = await fetch("https://jsonplaceholder.typicode.com/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(values),
        });
        if (!response.ok) throw new Error("Failed to add employee");
        const newEmployee = await response.json();
        dispatch(setEmployee([...existingEmployees, newEmployee])); // Update the store
      }

      onClose();
    } catch (error) {
      console.error("Error adding/editing employee:", error);
    }
  };

  const validationSchema = Yup.object({
    name: Yup.string().required("Name is required"),
    username: Yup.string().required("Username is required"),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required"),
  });

  return (
    <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h3 className="text-xl font-semibold mb-4">
          {employeeToEdit ? "Edit Employee" : "Add New Employee"}
        </h3>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          <Form>
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700">
                Name
              </label>
              <Field
                type="text"
                id="name"
                name="name"
                className="border w-full px-3 py-2 mt-1 rounded"
              />
              <ErrorMessage
                name="name"
                component="div"
                className="text-red-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="username" className="block text-gray-700">
                Username
              </label>
              <Field
                type="text"
                id="username"
                name="username"
                className="border w-full px-3 py-2 mt-1 rounded"
              />
              <ErrorMessage
                name="username"
                component="div"
                className="text-red-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700">
                Email
              </label>
              <Field
                type="email"
                id="email"
                name="email"
                className="border w-full px-3 py-2 mt-1 rounded"
              />
              <ErrorMessage
                name="email"
                component="div"
                className="text-red-500"
              />
            </div>
            <div className="flex justify-between">
              <button
                type="submit"
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
              >
                {employeeToEdit ? "Save Changes" : "Add Employee"}
              </button>
              <button
                type="button"
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                onClick={onClose}
              >
                Cancel
              </button>
            </div>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default AddEmployee;
