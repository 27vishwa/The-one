/** @type {import('tailwindcss').Config} */
const defaultTheme = require("tailwindcss/defaultTheme");
module.exports = {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      boxShadow: {
        cardShadow: "0 4px 24px 0 rgba(0, 0, 0, 0.08)", // The last value is the spread value
        dropdownShadow: "0 4px 4px 0 rgba(0, 0, 0, 0.4)", // The last value is the spread value
      },
      colors: {
        "primary-blue": "#262940",
        "site-yellow": "#FFD45A",
        "site-dark-black": "#292929",
        "site-black": "#121111",
        "light-grey": "#F6F6F6",
        "medium-grey": "#D9D9D9",
        "dark-grey": "#828282",
        "site-grey": "#a4a4a5",
        "site-red": "#DF3131",
        "site-green": "#1AB53C",
        "light-blue": "#2A2AF41A",
      },
      container: {
        center: true,
        padding: {
          DEFAULT: "12px",
          xl: "0",
        },
        screens: {
          sm: "100%",
          md: "100%",
          lg: "100%",
        },
      },
      fontFamily: {
        sans: ["League Spartan, sans-serif", ...defaultTheme.fontFamily.sans],
      },
      margin: {
        15: "60px",
        30: "30px",
      },
      padding: {
        15: "60px",
        30: "30px",
      },
      screens: {
        xs: "481px",
        // => @media (min-width: 481px) { ... }

        sm: "576px",
        // => @media (min-width: 576px) { ... }

        md: "768px",
        // => @media (min-width: 768px) { ... }

        lg: "992px",
        // => @media (min-width: 992px) { ... }

        xl: "1200px",
        // => @media (min-width: 1200px) { ... }

        xxl: "1400px",
        // => @media (min-width: 1400px) { ... }
      },
    },
  },
  plugins: [
    function ({ addComponents }) {
      addComponents({
        "@media (min-width: 1200px)": {
          ".container": {
            "max-width": "1140px",
            "padding-left": "0",
            "padding-right": "0",
          },
        },
      });
    },
  ],
};
